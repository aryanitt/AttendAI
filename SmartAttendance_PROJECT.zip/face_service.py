import os
import pickle
from typing import Any

import cv2
import numpy as np
from flask import current_app

_DEEPFACE = None


def _deepface():
    global _DEEPFACE
    if _DEEPFACE is None:
        from deepface import DeepFace

        _DEEPFACE = DeepFace
    return _DEEPFACE


def _model_name() -> str:
    return current_app.config.get("FACE_MODEL", "Facenet")


def _threshold() -> float:
    return float(current_app.config.get("FACE_THRESHOLD", 0.55))


def embedding_path(class_id: str) -> str:
    root = current_app.config["EMBEDDING_ROOT"]
    os.makedirs(root, exist_ok=True)
    return os.path.join(root, f"{class_id}.pkl")


def load_embeddings(class_id: str) -> dict[str, np.ndarray]:
    path = embedding_path(class_id)
    if not os.path.isfile(path):
        return {}
    with open(path, "rb") as f:
        raw = pickle.load(f)
    out = {}
    for sid, vec in raw.items():
        out[str(sid)] = np.asarray(vec, dtype=np.float64)
    return out


def save_embeddings(class_id: str, data: dict[str, np.ndarray]) -> None:
    path = embedding_path(class_id)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    serial = {k: v.tolist() for k, v in data.items()}
    with open(path, "wb") as f:
        pickle.dump(serial, f)


def remove_student_embedding(class_id: str, student_id: str) -> None:
    data = load_embeddings(class_id)
    data.pop(str(student_id), None)
    save_embeddings(class_id, data)


def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)
    if na < 1e-9 or nb < 1e-9:
        return 0.0
    return float(np.dot(a, b) / (na * nb))


def image_bytes_to_bgr(data: bytes) -> np.ndarray:
    arr = np.frombuffer(data, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Invalid image data")
    return img


def get_embedding_from_bgr(img_bgr: np.ndarray) -> np.ndarray:
    DeepFace = _deepface()
    rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    reps = DeepFace.represent(
        img_path=rgb,
        model_name=_model_name(),
        enforce_detection=True,
        detector_backend="opencv",
    )
    if not reps:
        raise ValueError("No face detected")
    emb = np.asarray(reps[0]["embedding"], dtype=np.float64)
    return emb


def detect_face_crops_opencv(img_bgr: np.ndarray) -> list[np.ndarray]:
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    cascade_path = (
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    )
    cascade = cv2.CascadeClassifier(cascade_path)
    rects = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
    h, w = img_bgr.shape[:2]
    crops = []
    for x, y, rw, rh in rects:
        pad = int(0.12 * max(rw, rh))
        x0, y0 = max(0, x - pad), max(0, y - pad)
        x1, y1 = min(w, x + rw + pad), min(h, y + rh + pad)
        crops.append(img_bgr[y0:y1, x0:x1])
    return crops


def extract_face_crops_bgr(img_bgr: np.ndarray) -> list[np.ndarray]:
    crops = detect_face_crops_opencv(img_bgr)
    if crops:
        return crops
    DeepFace = _deepface()
    rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    try:
        faces = DeepFace.extract_faces(
            img_path=rgb,
            detector_backend="opencv",
            enforce_detection=False,
        )
    except Exception:
        return []
    out = []
    for item in faces:
        face = item.get("face")
        if face is None:
            continue
        if face.dtype != np.uint8:
            face = (
                (face * 255).astype(np.uint8)
                if float(face.max()) <= 1.0
                else face.astype(np.uint8)
            )
        if len(face.shape) == 3 and face.shape[2] == 3:
            out.append(cv2.cvtColor(face, cv2.COLOR_RGB2BGR))
    return out


def match_embedding(
    emb: np.ndarray, roster: dict[str, np.ndarray]
) -> tuple[str | None, float]:
    best_id = None
    best_sim = -1.0
    thr = _threshold()
    for sid, ref in roster.items():
        sim = _cosine(emb, ref)
        if sim > best_sim:
            best_sim = sim
            best_id = sid
    if best_id is not None and best_sim >= thr:
        return best_id, best_sim
    return None, best_sim


def enroll_student_face(class_id: str, student_id: str, image_bytes: bytes) -> None:
    bgr = image_bytes_to_bgr(image_bytes)
    emb = get_embedding_from_bgr(bgr)
    data = load_embeddings(class_id)
    data[str(student_id)] = emb
    save_embeddings(class_id, data)
